
define([],function(){
    function homeCtrl($rootScope,$scope) {
        $scope.title='这里是疾病风险评估！';
    }

    return homeCtrl;
});